#Requires AutoHotkey v2.0
DetectHiddenWindows True

hWnd := WinExist("ahk_class Shell_TrayWnd")
if !hWnd
    ExitApp

; 現在のタスクバーが「表示」されているかチェック
style := WinGetStyle("ahk_class Shell_TrayWnd")

; APPBARDATA 構造体の準備 (x64: 48 bytes, x86: 36 bytes)
cbSize := (A_PtrSize = 8) ? 48 : 36
APPBARDATA := Buffer(cbSize, 0)
NumPut("UInt", cbSize, APPBARDATA, 0)
NumPut("Ptr", hWnd, APPBARDATA, (A_PtrSize = 8) ? 8 : 4)

if (style & 0x10000000) {
    ; --- ① まず「自動的に隠す(ABS_AUTOHIDE=1)」をONにして、ウィンドウの最大化領域を下まで広げる ---
    NumPut("Ptr", 1, APPBARDATA, (A_PtrSize = 8) ? 40 : 32)
    DllCall("Shell32\SHAppBarMessage", "UInt", 10, "Ptr", APPBARDATA)
    
    ; Windowsが領域を広げるアニメーションを少し待つ
    Sleep 300 
    
    ; --- ② その直後にタスクバーを「完全非表示」にする（これでマウスを下げても出なくなる） ---
    WinHide "ahk_class Shell_TrayWnd"
    if WinExist("ahk_class Shell_SecondaryTrayWnd") {
        WinHide "ahk_class Shell_SecondaryTrayWnd"
    }
} else {
    ; --- 元に戻す処理 ---
    ; ① まずタスクバーのウィンドウ自体の表示をオンにする
    WinShow "ahk_class Shell_TrayWnd"
    if WinExist("ahk_class Shell_SecondaryTrayWnd") {
        WinShow "ahk_class Shell_SecondaryTrayWnd"
    }
    
    ; ② 「常に表示(ABS_ALWAYSONTOP=2)」状態に戻して、領域を通常に戻す
    NumPut("Ptr", 2, APPBARDATA, (A_PtrSize = 8) ? 40 : 32)
    DllCall("Shell32\SHAppBarMessage", "UInt", 10, "Ptr", APPBARDATA)
}

ExitApp