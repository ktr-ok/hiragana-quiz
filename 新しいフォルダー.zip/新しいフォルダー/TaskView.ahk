Send "#{Tab}"
Sleep 50
Send "{LWin up}{RWin up}"